#!/usr/bin/perl -w

#Constants
my $cGsddWS = "Server.wsdl";
my $cGsddXSD = "Schema.xsd";
my $cGsddServer = "GSDDServer";
my $cGsddUpdate = "GSDDUpdate";
my $cGsddExport = "GSDDExport";

my $cDefaultSourceBinPath = './bin/';
my $cDefaultInstallBinPath = '/opt/goldstandard/gsdd5/';
my $cDefaultInstallLinkPath = '/usr/bin/';

# Tell if the user is the super user
sub is_root {
  return $> == 0;
}

# Print an error message and exit
sub error {
  my $msg = shift;

  print(STDERR $msg . "\n\n" . "Execution aborted.\n\n");
  exit 1;
}

#get a path from the user
sub get_path {
  my $prompt = shift;
  my $defaultPath = shift;
 
  print("$prompt\n[$defaultPath]");
  chomp($path = <>);

  if($path eq "") {
    $path = $defaultPath;
  }

  #Is separator at end of path?
  if(substr($path, -1) ne '/') {
    $path = $path . '/';
  }

  #Is this the home dir?
  if(substr($path, 0, 2) eq '~/') {
    substr($path, 0, 1) = $ENV{HOME};
  }

  #Is this a releative path?
  if(substr($path, 0, 1) ne '/') { 
   $path = "$ENV{PWD}/$path";
  }
  
  return $path;
}

sub get_yes_no_answer {
  my $prompt = shift;
  my $defaultAnswer = shift;

  print("\n$prompt");
  if($defaultAnswer eq "Yes"){
    print(" [Yes] or No\n");
  } 
  else {
    print(" Yes or [No]");
  }
  chomp($answer = <>);
  if($answer eq "" && 
    $defaultAnswer eq "Yes"){
      return 1;
  }
  if(uc($answer) eq "Y" || 
    uc($answer) eq "YE" || 
    uc($answer) eq "YES" ){
    return 1;
  }
  return 0;
}

#installs the GSDD binaries
sub install_binaries {
  $path = get_path(
    'Enter path for GSDD binaries', 
    $cDefaultInstallBinPath);

  system("mkdir", "-p", $path);
  print($path . " created.\n");

  system("chmod", "777", $path);
  print($path . " permissions set.\n");

  system("cp", "$cDefaultSourceBinPath$cGsddWS", "$path$cGsddWS");
  print("$path$cGsddWS installed.\n");

  system("cp", "$cDefaultSourceBinPath$cGsddXSD", "$path$cGsddXSD");
  print("$path$cGsddXSD installed.\n");
 
  system("cp", "$cDefaultSourceBinPath$cGsddServer", "$path$cGsddServer");
  print("$path$cGsddServer installed.\n");

  system("cp", "$cDefaultSourceBinPath$cGsddUpdate", "$path$cGsddUpdate");
  print("$path$cGsddUpdate installed.\n");

  system("cp", "$cDefaultSourceBinPath$cGsddExport", "$path$cGsddExport");
  print("$path$cGsddExport installed.\n");
 
  install_symlinks($path);
}

#installs the symbolic links to GSDD binaries 
sub install_symlinks {
  my $binPath = shift;
  
  if(get_yes_no_answer('Create symbolic links?', 'Yes')){
    $path = get_path(
      'Enter path for symbolic links',
      $cDefaultInstallLinkPath);

    system("mkdir", "-p", $path);

    create_servicelinks($binPath, $path, $cGsddServer);
    create_symlink($binPath, $path, $cGsddUpdate);	
    create_symlink($binPath, $path, $cGsddExport);	    
  }
  else
  {
    print("Symbolic links not installed.");
  }
}

#creates a standard symlink 
sub create_symlink {
  my $binPath = shift;
  my $linkPath = shift;
  my $binary = shift;

  open(LINK_FH, "> $linkPath$binary") or die;
  print(LINK_FH "\#\!$ENV{SHELL}\n\n" );
  print(LINK_FH "CurrentDir=\$(pwd)\n");
  print(LINK_FH "cd $binPath\n");
  print(LINK_FH "./$binary \$1 \$2 \$3\n");
  print(LINK_FH "cd \$CurrentDir\n");
  close(LINK_FH);
  system("chmod", "+x", "$linkPath$binary");
  print("$linkPath$binary created.\n");
}

#creates symlinks to start and stop a background process
sub create_servicelinks{
  my $binPath = shift;
  my $linkPath = shift;
  my $binary = shift;
  my $start = "Start";
  my $stop = "Stop";

  open(LINK_FH, "> $linkPath$binary$start") or die;
  print(LINK_FH "\#\!$ENV{SHELL}\n\n" );
  print(LINK_FH "CurrentDir=\$(pwd)\n");
  print(LINK_FH "cd $binPath\n");
  print(LINK_FH "./$binary &\n");
  print(LINK_FH "sleep 1s\n");
  print(LINK_FH "cd \$CurrentDir\n");
  close(LINK_FH);
  system("chmod", "+x", "$linkPath$binary$start");
  print("$linkPath$binary$start created.\n");

  open(LINK_FH, "> $linkPath$binary$stop") or die;
  print(LINK_FH "\#\!$ENV{SHELL}\n\n" );
  print(LINK_FH "echo Stopping GSDD Server Process...\n");
  print(LINK_FH "killall -w $binary\n");
  print(LINK_FH "echo GSDD Server Stopped.\n");
  close(LINK_FH);
  system("chmod", "+x", "$linkPath$binary$stop");
  print("$linkPath$binary$stop created.\n");
}

# Program entry point
sub main {
  if (not is_root()) {
    error('Please re-run this program as the super user.');
  }
  else {
    print("\nThis program will install GSDD binaries and create symbolic link files.\n"); 
    if(get_yes_no_answer('Do you wish to continue?', 'No')){
      install_binaries();
      print("\nInstallation Complete - Enjoy!\n\n");
    }
    else {
      error('Halting installation...');
    }
  }
}

main();



