DROP TABLE IF EXISTS dates;
DROP TABLE IF EXISTS tmp;
DROP TABLE IF EXISTS tmp2;
CREATE TABLE tmp (n int);
INSERT INTO tmp VALUES (1), (2), (3), (4), (5), (6), (7), (8), (9), (10);
