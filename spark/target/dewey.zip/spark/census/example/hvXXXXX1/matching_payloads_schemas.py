from spark.helpers.source_table import PayloadTable

TABLE_CONF = {
    'example': PayloadTable()
}
