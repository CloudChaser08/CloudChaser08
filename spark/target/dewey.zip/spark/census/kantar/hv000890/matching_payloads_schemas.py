from spark.helpers.source_table import PayloadTable

TABLE_CONF = {
    'kantar': PayloadTable()
}
