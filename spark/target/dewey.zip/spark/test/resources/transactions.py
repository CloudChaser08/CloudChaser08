TABLES = ['raw']

TABLE_COLUMNS = {
    'raw' : [
        'id',
        'diagnosis_code',
        'diagnosis_code_qual',
        'prescribing_npi',
        'notes'
    ]
}
