ALTER TABLE {table_name} ADD PARTITION ({partition_identifiers}) LOCATION {partition_location};
