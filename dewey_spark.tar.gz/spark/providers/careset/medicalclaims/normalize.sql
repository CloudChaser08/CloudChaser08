SELECT
    npi                         AS prov_rendering_npi,
    cpt_code                    AS procedure_code
FROM careset_transactions
