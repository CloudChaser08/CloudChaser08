# day they started sending results
RESULTS_START_DATE = '2017-09-26'
